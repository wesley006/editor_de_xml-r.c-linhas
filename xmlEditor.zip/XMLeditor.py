"""
editor de xml
"""
import os
from arquivo import *
def ver(a,b,c1=0,d=0):
    x=False
    if str(c)[n2:n2+len(a)] in a or str(c)[n2:n2+len(b)] in b:
        x=True
        return f"\033[0;3{c1};4{d}m{c}\033[m"

editado='/sdcard/editor/editado/AndroidManifest.xml'
try:
    a=open('/sdcard/editor/AndroidManifest.xml','rt')
except:
    print(''' ocorreu um erro durante a operação
 arquivo /sdcard/editor/AndroidManifest não encontrado
 Crie uma pasta nomeada "editor" e ponha o arquivo AndroidManifest.xml nela''')
else:
    print(' iniciando..')
    while True:
        if arqv(editado):
            print(' Arquivo aberto com exito')
            break
        else:
            try:
                os.mkdir('/sdcard/editor/editado')
            except:
                criararquivo(editado)
                break
    try:
        subs=open('/sdcard/editor/editado/AndroidManifest.xml','rt+')
    except:
        print(' ocorreu um erro durante a operação')
    listagem=list()
    edit=''
    edit2=''
    res1=res2=x1=x2=x3=x4=x5=x6=x7=x8=0
    for linha, c in enumerate(a.readlines()):
        for n2, af2 in enumerate(c):
            if ver('<activity','</activity'):
                x1+=1
                print(f' x1={x1}')
                print(ver('<activity','</activity',c1=1,d=3))
                subs.write(c)

            if ver('<intent-filter','</intent-filter'):
                x2+=1
                print(f' x2={x2}')
                print(ver('<intent-filter','</intent-filter',c1=4,d=7))
                subs.write(c)

            if ver('<provider','</provider'):
                x3+=1
                print(f' x3={x3}')
                print(ver('<provider','</provider',c1=0,d=2))
                subs.write(c)

            if ver('<receiver','</receiver'):
                x4+=1
                print(f' x4={x4}')
                print(ver('<receiver','</receiver',c1=3,d=4))
                subs.write(c)

            if ver('<service','</service'):
                x5+=1
                print(f' x5={x5}')
                print(ver('<service','</service',c1=0,d=2))
                subs.write(c)

            if ver('<application','</application'):
                x6+=1
                print(f' x6={x6}')
                print(ver('<application','</application',c1=0,d=7))
                subs.write(c)

            if ver('<manifest','</manifest'):
                x7+=1
                print(f' x7={x7}')
                print(ver('<manifest','</manifest',c1=6,d=5))
                subs.write(c)

           if ver('<?xml version=','<?xml version='):
                x8+=1
                print(f' x8={x8}')
                print(ver('<?xml version=','<?xml version=',c1=3,d=7))
                subs.write(c)

                
            if x1<=0 and x2<=0 and x3<=0 and x4<=0 and x5<=0 and x6<=0 and x7<=0 and x8<=0:
                if af2 in '<':
                    edit2+=af2
                if af2 in '/' and len(edit2)==1:
                    edit2+=af2
                    print(f' referência : {edit2}')
                if len(edit2)==2 and af2 in '>':
                    edit2+=af2
                if len(edit2)>=3:
                    res2+=1
            if len(edit2)>0 and x1<=0 and x2<=0 and x3<=0 and x4<=0 and x5<=0 and x6<=0 and x7<=0 and x8<=0:
                for n, af in enumerate(c):
                    if af=='<':
                        edit+=af
                    if len(edit)>=2:
                        if af=='>' and len(edit2)<=1:
                            r=str(c).replace(str(c)[n],'/>')
                            res1+=1

        print(x1, x2, x3, x4, x5, x6, x7, x8, len(edit))
        if res1>=1:
            print(f'\033[0;31m R1 = {r} N {n} C {c[n]}\033[m')
            subs.write(r)
        if res2>=1:
            print(f'\033[0;31;47m R2 = {c} N2 {n2} C {c[n2]}\033[m')
        print(f'\033[0;32m{c}\033[m')
        x1=x2=x3=x4=x5=x6=x7=x8=res1=res2=0
        edit=''
        edit2=''

    a.close()
    subs.close()
    print(x1, x2, x3, x4, x5, x6, x7, x8)

"""
<?xml version="1.0" encoding="utf-8"?>

<activity
</activity

<intent-filter</intent-filter

<provider</provider

<receiver</receiver

<service</service

<application</application

<manifest</manifest
"""
