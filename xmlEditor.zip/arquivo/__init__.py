# rt = read text ler texto
from interface import *
def arqv(nome):
    try:
        a=open(nome,'rt')
        a.close()
    except Exception as erro:
        return False
    else:
        return True


def criararquivo(nome):
    try:
        a=open(nome,'wt+')
        a.close()
    except Exception as erro:
        msg=f'''não foi possível criar o arquivo
 {erro}'''
        titulo3(dc='-',t=len(msg),a=(0,1,7),b=(7,7,0),c=(0,1,7),tt=msg)
    else:
        msg2='arquivo criado com sucesso !'
        titulo3(dc='-',t=len(msg2),a=(0,2,7),b=(7,7,0),c=(0,2,7),tt=msg2)



def lerarquivo(nome):
    try:
        b=open(nome,'rt')
    except:
        msg=f'Não foi possível ler o arquivo "{nome}"'
        titulo3(dc='-',t=len(msg),a=(0,1,7),b=(7,7,0),c=(0,1,7),tt=msg)
    else:
        listagem(b.readlines())
        b.close()
