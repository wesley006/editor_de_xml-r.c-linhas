

# a : estilo do caractere  b : cor do caractere c : cor de fundo d : txt
def cores(a=0,b=0,c=0,d=' '):
    return f'\033[{a};3{b};4{c}m {d} \033[m'


# 1º tamanho 2º txt
def titulo2(a=0,b=' '):
    tm=51-a
    spc=' '*tm
    return f' {b}{spc}'


# 1º txt
def titulo(a=' '):
    print('"'*50)
    print(f'{a}'.center(50,' '))
    print('"'*50)


# dc : decoração t : tamanho ,1º : estilo do caractere,  2º : cor do caractere, 3º : cor de fundo tt : txt
def titulo3(dc=' ',t=0,a='0,0,0',b='0,0,0',c='0,0,0',tt=' '):
    try:
        print(f'{cores(a[0],a[1],a[2],d=(dc*53))}')
        print(f'{cores(b[0],b[1],b[2],d=(tt.center(53," ")))}')
        print(f'{cores(c[0],c[1],c[2],d=(dc*53))}')
    except:
        print('\033[7;37m Erro : modulo cores não foi importado \03[m')


